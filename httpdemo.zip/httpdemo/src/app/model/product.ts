export class Product {
    name: string;
    price: number;
    id: number;
}
