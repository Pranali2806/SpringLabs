import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Product } from '../model/product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private service: ProductService) { }

  product = new Product();
  productArr: Product[] = [];
  ngOnInit() {
    this.getAll();
  }

  getAll() {
    this.service.getAll().subscribe(
      result => { this.productArr = result; },
      error => { console.log(error); }
    );
  }
  addOneProduct() {
    this.product.name = 'Apple';
    this.product.price = 467.58;

    this.service.postOne(this.product).subscribe(
      result => {
        console.log(result);
        console.log('Added Successfully');
      }, error => { console.log(error); }
    );
  }

  getOneProduct() {
    this.service.getOne(this.productArr[0].id).subscribe(
      result => {
        console.log(result);
      }, error => { console.log(error); }
    );
  }

  updateProduct() {
    this.product = this.productArr[0];
    this.product.name = 'updatedName';

    this.service.putOne(this.product).subscribe(
      result => {
        console.log(result);
      }, error => { console.log(error); }
    );
  }

  deleteProduct() {
    this.service.deleteOne(this.productArr[0].id).subscribe(
      res => {
        console.log('Deleted succesfully');
      }, error => { console.log(error); }
    );
  }

}
