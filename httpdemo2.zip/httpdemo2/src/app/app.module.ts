import { BrowserModule } from '@angular/platform-browser';
import {ModuleWithProviders, NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';


import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { NewArrivalComponent } from './new-arrival/new-arrival.component';
import { TopNavbarComponent } from './top-navbar/top-navbar.component';
import { AppRoutingModule } from './/app-routing.module';
import { NgxImageZoomModule } from 'ngx-image-zoom';
// material
import {MatButtonModule} from '@angular/material/button';

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    NewArrivalComponent,
    TopNavbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    NgxImageZoomModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  static forRoot(): ModuleWithProviders {
    return {
        ngModule: NgxImageZoomModule,
    };
}
}
