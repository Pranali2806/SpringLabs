package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;
import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "lib//mydriver/chromedriver.exe");
		
		
	}

	@Given("^User is on 'PersonalDetails' Page$")
	public void user_is_on_PersonalDetails_Page() throws Throwable {
		driver = new ChromeDriver();
		personal = new Personal();
		PageFactory.initElements(driver, personal);
		driver.get("C://Users//prawati//BDD//PersonDetails//html/PersonalDetails.html");
		
	}

	@When("^user enetrs invalid firstName$")
	public void user_enetrs_invalid_firstName() throws Throwable {
		personal.setFirstName("");
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		personal.submitPersonalDetails();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enetrs invalid lastName$")
	public void user_enetrs_invalid_lastName() throws Throwable {
		personal.setFirstName("Pranali");
		personal.setLastName("");
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		personal.submitPersonalDetails();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enetrs invalid email$")
	public void user_enetrs_invalid_email() throws Throwable {
		personal.setFirstName("Pranali");
		personal.setLastName("Awati");
		personal.setEmail("");
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		personal.submitPersonalDetails();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enetrs invalid contact number$")
	public void user_enetrs_invalid_contact_number() throws Throwable {
		personal.setFirstName("Pranali");
		personal.setLastName("Awati");
		personal.setEmail("pranali2806@gmail.com");
		personal.setPhoneNumber("");
	}

	@Then("^display 'Please fill valid Contact no\\.'$")
	public void display_Please_fill_valid_Contact_no() throws Throwable {
		personal.submitPersonalDetails();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enetrs invalid Address Line (\\d+)$")
	public void user_enetrs_invalid_Address_Line(int arg1) throws Throwable {
		personal.setFirstName("Pranali");
		personal.setLastName("Awati");
		personal.setEmail("pranali2806@gmail.com");
		personal.setPhoneNumber("7083335931");
		personal.setAddress1("");
	}

	@Then("^display 'Please fill Address Line (\\d+)'$")
	public void display_Please_fill_Address_Line(int arg1) throws Throwable {
		personal.submitPersonalDetails();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enetrs invalid City$")
	public void user_enetrs_invalid_City() throws Throwable {
		personal.setFirstName("Pranali");
		personal.setLastName("Awati");
		personal.setEmail("pranali2806@gmail.com");
		personal.setPhoneNumber("7083335931");
		personal.setAddress1("100 ft road");
		personal.setAddress2("Sangli");
		personal.clickCity("Select City");
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
		personal.submitPersonalDetails();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enetrs invalid State$")
	public void user_enetrs_invalid_State() throws Throwable {
		personal.setFirstName("Pranali");
		personal.setLastName("Awati");
		personal.setEmail("pranali2806@gmail.com");
		personal.setPhoneNumber("7083335931");
		personal.setAddress1("100 ft road");
		personal.setAddress2("Sangli");
		personal.clickCity("Pune");
		personal.clickState("Select State");
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
		personal.submitPersonalDetails();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		personal.setFirstName("Pranali");
		personal.setLastName("Awati");
		personal.setEmail("pranali2806@gmail.com");
		personal.setPhoneNumber("7083335931");
		personal.setAddress1("100 ft road");
		personal.setAddress2("Sangli");
		personal.clickCity("Pune");
		personal.clickState("Maharashtra");
	}

	@Then("^display 'Personal details are validated'$")
	public void display_Personal_details_are_validated() throws Throwable {
		personal.submitPersonalDetails();
		String expectedMessage = "Personal details are validated and accepted sucessfully.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	/*@After
	public void closeDriver() {
		driver.close();
	}*/

}
