package com.cg.step;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDefinition {

	private WebDriver driver;
	private Education education;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "lib//mydriver/chromedriver.exe");		
	}
	
	@Given("^user is on Education Details page$")
	public void user_is_on_Education_Details_page() throws Throwable {
		driver = new ChromeDriver();
		education = new Education();
		PageFactory.initElements(driver, education);
		driver.get("C://Users//prawati//BDD//PersonDetails//html/EducationDetails.html");
	}

	@When("^user enters loads the page$")
	public void user_enters_loads_the_page() throws Throwable {
	    
	}

	@Then("^valid page should open$")
	public void valid_page_should_open() throws Throwable {
		String expectedPageTitle = "Educational Details";
		String actualPageTitle = driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		driver.close();
	}

	@When("^user enters invalid graduation$")
	public void user_enters_invalid_graduation() throws Throwable {
	    education.clickGraduation("Select Graduation");
	}

	@Then("^displays 'Please fill Graduation'$")
	public void displays_Please_fill_Graduation() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid percentage$")
	public void user_enters_invalid_percentage() throws Throwable {
		education.clickGraduation("BE");
		education.setPercentage("");
	}

	@Then("^displays 'Please fill Percentage'$")
	public void displays_Please_fill_Percentage() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid passing year$")
	public void user_enters_invalid_passing_year() throws Throwable {
		education.clickGraduation("BE");
		education.setPercentage("75");
		education.setPassingYear("");
	}

	@Then("^displays 'Please fill passing year'$")
	public void displays_Please_fill_passing_year() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid project name$")
	public void user_enters_invalid_project_name() throws Throwable {
		education.clickGraduation("BE");
		education.setPercentage("75");
		education.setPassingYear("2018");
		education.setProjectName("");
	}

	@Then("^displays 'Please fill Project name '$")
	public void displays_Please_fill_Project_name() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters invalid technologies$")
	public void user_enters_invalid_technologies() throws Throwable {
		education.clickGraduation("BE");
		education.setPercentage("75");
		education.setPassingYear("2018");
		education.setProjectName("Lab Automation");
	}

	@Then("^displays 'Please fill Technologies'$")
	public void displays_Please_fill_Technologies() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters valid education details$")
	public void user_enters_valid_education_details() throws Throwable {
		education.clickGraduation("BE");
		education.setPercentage("75");
		education.setPassingYear("2018");
		education.setProjectName("Lab Automation");
		education.clickTechnologies("Angular");
	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		education.clickMakePayment();
		String expectedMessage="Your registration has successfully done.Please check registered mail for activation link!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	/*@After
	public void closeDriver() {
		driver.close();
	}*/
}
