package com.cg.repo;

import java.util.List;

import com.cg.entity.Product;

public interface ProductRepo {
	Product saveProduct(Product p);
	List<Product> getAll();
	
}
