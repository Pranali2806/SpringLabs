package com.cg.rest;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	ITraineeService its;
	
	Trainee trainee;
	ArrayList<String> traineeLocation;
	ArrayList<String> traineeDomain;
	
	
	// start page - login
	@RequestMapping("/")
	public String openIndex(Model m) {
		m.addAttribute("login", new Login());
		return "Login";
	}

	@RequestMapping("checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login login, BindingResult result, Model m) // Binding res-
																											// stores
																											// errors
	{
		// Logic to validate userName and password
		if (result.hasErrors()) {
			return "Login";
		} else {
			// Logic to validate userName and password against database
			if (login.getUserName().equals("Pranali") && login.getPassword().equals("pilot")) {
				return "Menu";
			} else {
				m.addAttribute("failmsg", "Invalid Credentials");
				return "Login";
			}
		}

	}
	
	// Add Trainee
	@RequestMapping("addTrainee")
	public String addTrainee(@ModelAttribute("trainee") @Valid Trainee trainee, BindingResult result, Model m) {
	// Validate form details
		if (result.hasErrors()) {
			m.addAttribute("failmsg", "Invalid Trainee data");
			m.addAttribute("traineeLocation", traineeLocation);
			m.addAttribute("traineeDomain", traineeDomain);
			return "AddTrainee";
		} else {
			// Add Trainee
			its.saveTrainee(trainee);
			m.addAttribute("successMsg", "Added Successfully");
			return "Menu";
		}
	}
	@RequestMapping("/AddTrainee")
	public String prepareRegister(Model model)
	{
		traineeLocation =new ArrayList<String>();
		
		traineeLocation.add("Pune");
		traineeLocation.add("Mumbai");
		traineeLocation.add("Chennai");
		traineeLocation.add("banglore");
		
		traineeDomain =new ArrayList<String>();
		
		traineeDomain.add("IT");
		traineeDomain.add("Networking");
		
		model.addAttribute("traineeLocation",traineeLocation);
		model.addAttribute("traineeDomain",traineeDomain);
		
		model.addAttribute("trainee",new Trainee());
	    return "AddTrainee";	
	}
	
	// Get Trainee by traine Id
	@RequestMapping("findByID")
	public String getTraineeById(int traineeId, Model m) {
		trainee = its.getTraineeById(traineeId);
		if(trainee != null) {
			m.addAttribute("traineeToBeDeleted", trainee);
		} else {
			m.addAttribute("traineeToBeDeleted", null);
			m.addAttribute("failMsg", "Invalid Id");
		}
		return "DeleteTrainee";
	}
	
	// delete trainee
	@RequestMapping("/DeleteTrainee")
	public String deleteTrainee(Model m) {
		m.addAttribute("traineeToBeDeleted", null);
		return "DeleteTrainee";
	}

	@RequestMapping("delete")
	public String delete(Model m) {
		if (trainee != null) {
			its.deleteTrainee(trainee.getTraineeId());
			trainee = null;
			m.addAttribute("successMsg", "Trainee deleted");
			return "Menu";
		} else {
			m.addAttribute("failMsg", "Invalid Id");
			return "DeleteTrainee";
		}
	}
	
	// Retrieve Trainee
	@RequestMapping("/RetrieveTrainee")
	public String retrieveTrainee(Model m) {
		m.addAttribute("retrievedTrainee", null);
		return "RetrieveTrainee";
	}
	@RequestMapping("retrieve")
	public String retrieve(Model m) {
		if (trainee != null) {
			its.getTraineeById(trainee.getTraineeId());
			trainee = null;
			m.addAttribute("successMsg", "Trainee deleted");
			return "Menu";
		} else {
			m.addAttribute("failMsg", "Invalid Id");
			return "RetrieveTrainee";
		}
	}
	
	// Retrieve all trainee
	@RequestMapping("/retrieveAll")
	public String retrieveAll(Model m) {
		Iterable<Trainee> iterable = its.getAllTrainee();
		List<Trainee> list = new ArrayList<>();
		iterable.forEach(list::add);
		m.addAttribute("list", list);
		return "RetrieveAllTrainee";
	}
	
	// Modify Trainee
	@RequestMapping("/modifyTrainee")
	public String modify(Model m) {
		traineeLocation = new ArrayList<String>();
		traineeDomain = new ArrayList<String>();
		traineeLocation.add("Mumbai");
		traineeLocation.add("Bangalore");
		traineeLocation.add("Chennai");
		traineeLocation.add("Delhi");
		traineeDomain.add("IT");
		traineeDomain.add("Networking");
		m.addAttribute("trainee", new Trainee());
		m.addAttribute("traineeLocation", traineeLocation);
		m.addAttribute("traineeDomain", traineeDomain);
		return "ModifyTrainee";

	}

	@RequestMapping("traineeToBeModified")
	public String getTraineeByTraineeId(int traineeId, Model m) {
		trainee = its.getTraineeById(traineeId);
		System.out.println(trainee);
		m.addAttribute("trainee", trainee);
		m.addAttribute("traineeLocation", traineeLocation);
		m.addAttribute("traineeDomain", traineeDomain);
		return "modifyTrainee";
	}

	@RequestMapping("modify")
	public String modifyTrainee(@ModelAttribute("trainee") Trainee trainee, BindingResult result, Model m) {
		if (result.hasErrors()) {
			m.addAttribute("failmsg", "Invalid");
			m.addAttribute("traineeLocation", traineeLocation);
			m.addAttribute("traineeDomain", traineeDomain);
			return "modifyTrainee";
		} else {
			its.saveTrainee(trainee);
			m.addAttribute("successMsg", "Modified Successfully!");
			return "Menu";
		}
	}
	
}
