package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "trainee")
public class Trainee implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(length = 20)
	private int traineeId;
	@Column(length = 20)
	@NotNull(message = "This field is required")
	private String traineeName;
	@Column(length = 20)
	@NotNull(message = "This field is required")
	private String traineeDomain;
	@Column(length = 20)
	@NotNull(message = "This field is required")
	private String traineeLocation;

	public Trainee() {

	}

	public Trainee(int traineeId, String traineeName, String traineeDomain, String traineeLocation) {
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeDomain = traineeDomain;
		this.traineeLocation = traineeLocation;
	}

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}
}
