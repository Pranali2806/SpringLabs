package com.cg.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.entity.Trainee;

@Repository
public interface TraineeRepo  extends CrudRepository<Trainee, Integer>{

}
