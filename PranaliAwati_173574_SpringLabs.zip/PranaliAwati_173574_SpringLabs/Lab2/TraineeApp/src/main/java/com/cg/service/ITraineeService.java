package com.cg.service;


import com.cg.entity.Trainee;

public interface ITraineeService {
	void saveTrainee(Trainee employee);

	Trainee getTraineeById(int empId);

	Trainee updateTrainee(Trainee employee);

	Iterable<Trainee> getAllTrainee();

	String deleteTrainee(int empId);
}
