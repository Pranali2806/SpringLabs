package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Service
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	TraineeRepo traineeRepo;

	@Override
	public void saveTrainee(Trainee trainee) {
		traineeRepo.save(trainee);
	}

	@Override
	public Trainee getTraineeById(int traineeId) {
		return traineeRepo.findById(traineeId).get();
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		Trainee t = new Trainee();
		t = traineeRepo.findById(trainee.getTraineeId()).get();
		traineeRepo.save(trainee);
		return trainee;
	}

	@Override
	public Iterable<Trainee> getAllTrainee() {
		return traineeRepo.findAll();
	}

	@Override
	public String deleteTrainee(int traineeId) {
		Trainee trainee;
		trainee = traineeRepo.findById(traineeId).get();
		traineeRepo.delete(trainee);
		return "Record deleted successfully!";
	}

}
